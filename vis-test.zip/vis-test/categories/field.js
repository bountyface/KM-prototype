const PUBLIC_TRANSPORT = "publicTransport";
const PRIVATE_TRANSPORT = "privateTransport";
const SHARED_MOBILITY = "sharedMobility";

const fieldArray = [
	{ id: PUBLIC_TRANSPORT, label: "Public Transport" },
	{ id: PRIVATE_TRANSPORT, label: "Private Transport" },
	{ id: SHARED_MOBILITY, label: "Shared Mobility" },
];
