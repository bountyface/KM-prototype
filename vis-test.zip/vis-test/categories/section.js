const EDUCATION_AND_TRAINING = "educationAndTraining";
const AWARENESS = "awareness";
const DEVELOPMENT = "development";
const DESIGN = "design";
const EMPLOYMENT = "employment";
const SAFETY_AND_SECURITY = "safetyAndSecurity";
const ETC = "etc";

const sectionArray = [
	{ id: EDUCATION_AND_TRAINING, label: "Education and Training" },
	{ id: AWARENESS, label: "Awareness" },
	{ id: DEVELOPMENT, label: "Development" },
	{ id: DESIGN, label: "Design" },
	{ id: EMPLOYMENT, label: "Employment" },
	{ id: SAFETY_AND_SECURITY, label: "Safety and Security" },
	{ id: ETC, label: "etc." },
];
