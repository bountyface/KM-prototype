const EQUALITY = "equality";
const ACCESSIBILITY = "accessibility";
const INCLUSION = "inclusion";
const PARTICIPATION = "participation";
const SUSTAINABILITY = "sustainability";

const gd_goalArray = [
	{ id: EQUALITY, label: "Equality" },
	{ id: ACCESSIBILITY, label: "Accessibility" },
	{ id: INCLUSION, label: "Inclusion" },
	{ id: PARTICIPATION, label: "Participation" },
	{ id: SUSTAINABILITY, label: "Sustainability" },
];
