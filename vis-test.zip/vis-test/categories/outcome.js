const PRODUCTS = "products";
const SERVICES = "services";
const PROCESSES = "processes";

const outcomeArray = [
	{ id: PRODUCTS, label: "Products" },
	{ id: SERVICES, label: "Services" },
	{ id: PROCESSES, label: "Processes" },
];
